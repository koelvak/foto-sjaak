﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace foods
{
   public class Demon
    {
       //field
      private Texture2D texture;
      private Rectangle destinationRect, sourceRect;
      private SpriteEffects effect;
      private float timer = 0f;
      private int speed;
      private SoundEffect sound, soundDie;
     
     
      //properties
      public Rectangle DestinationRect
      {
          get { return this.destinationRect; }
      }

      public SoundEffect SoundDie
      {
          get { return this.soundDie; }
      }


      //constructor
      public Demon(ContentManager content, Vector2 position)
      {
          this.texture = content.Load<Texture2D>(@"pictures\demon");
          this.sound = content.Load<SoundEffect>(@"music\Zombie Moan");
          this.soundDie = content.Load<SoundEffect>(@"music\bite");
          this.destinationRect = new Rectangle((int)position.X, 
                                                (int)position.Y, 
                                                130 * 1/2, 
                                                140 * 1/2);
          this.sourceRect = new Rectangle(0, 0, 130, 140);
          this.effect = SpriteEffects.None;
          this.speed = -10;
          this.sound.Play(1.0f, 0.0f, 0.0f);
      }

      //update
     public void update()
      {
          if (this.timer > 2f / 60f)
          {
              if (this.sourceRect.X < 380)
              {
                  this.sourceRect.X += 130;
              }
              else
              {
                  this.sourceRect.X = 0;
                 
              }
              this.timer = 0f;
          }
          else
          {
              this.timer += 1f / 60f;
          }

         // De Enemy gaan omhoog en omlaag
          if (this.destinationRect.Y < 0 || this.destinationRect.Y > 350)
          {
              this.speed = this.speed * -1;
          }
          this.destinationRect.X += this.speed;
                
      } 



         //draw
         public void Draw(SpriteBatch spriteBatch)
         {
             spriteBatch.Draw(this.texture, this.destinationRect, this.sourceRect, Color.White, 0f, Vector2.Zero, this.effect, 0.3f);
         }
    }
}
