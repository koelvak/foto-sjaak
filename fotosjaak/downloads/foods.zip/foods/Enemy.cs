﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace foods
{
  public class Enemy
    {
      //field
      private Texture2D texture;
      private Rectangle destinationRect, sourceRect;
      private SpriteEffects effect;
      private float timer, demonTimer;
      private int speed;
      private List<Demon> demonList;
      private ContentManager content;
      private Random random;
      private float randomNumber = 0;
   

      //properties
      public List<Demon> DemonList
      {
          get { return this.demonList; }
      }

      //constructor
      public Enemy(ContentManager content, Vector2 position)
      {
          this.texture = content.Load<Texture2D>(@"pictures\Enemy");

          this.destinationRect = new Rectangle((int)position.X,
                                               (int)position.Y,
                                                135, 165);
          this.sourceRect = new Rectangle(0, 0, 135, 165);
          this.effect = SpriteEffects.None;
          this.speed = -3;
          this.content = content;
          this.demonList = new List<Demon>();
          this.random = new Random();
      }

      //update
     public void update()
      {

          #region Mydemon
          if (this.timer > 1f / 60f)
          {
              if (this.sourceRect.X < 405)
              {
                  this.sourceRect.X += 135;
              }
              else
              {
                  this.sourceRect.X = 0;

              }
              this.timer = 0f;
          }
          else
          {
              this.timer += 1f / 60f;
          }

          // De Enemy gaan omhoog en omlaag
          if (this.destinationRect.Y < 0 || this.destinationRect.Y > 350)
          {
              this.speed = this.speed * -1;
          }
          this.destinationRect.Y += this.speed; 
          #endregion

          this.random.Next(100);

          if (this.demonTimer > (30 + this.randomNumber) / 60f)
          {
              this.demonList.Add(new Demon(this.content, new Vector2(this.destinationRect.X,
                                                                       this.destinationRect.Y)));

              this.demonTimer = 0f;
              this.randomNumber = this.random.Next(60);

          }
          else
          {
              this.demonTimer += 1f / 60f;
          }

         foreach (Demon demon in this.demonList)
         {
             demon.update();
             if (demon.DestinationRect.X < -175)
             {
                 this.demonList.Remove(demon);
                 break;
             }
         }
      } 



         //draw
         public void Draw(SpriteBatch spriteBatch)
         {
             spriteBatch.Draw(this.texture, this.destinationRect, this.sourceRect, Color.White, 0f, Vector2.Zero, this.effect, 0.3f);
             foreach (Demon demon in this.demonList)
             {
                 demon.Draw(spriteBatch);

             }
         }

    }
}
