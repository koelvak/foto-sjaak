using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace foods
{

    public enum GameState { start, play, GameOver };

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private Texture2D background, animatedSprite;
        private Vector2 position;
        private Rectangle backgroundRect, cameraRect;
        private float timer = 0f, animatedSpriteTimer = 0f;
        private KeyboardState ks, oldKeyboardState;
        private SpriteEffects effect = SpriteEffects.None;
        private AnimatedSprite walkingMan_1;
        private Enemy enemy;
        private SpriteFont arial;
        private int score = 0;
        private GameState state = GameState.start;
        private Song music;
        private bool day;
    

        //properties
        public int Score
    {
        get { return this.score;}
        set { this.score = value;}
    }
        
       
        //dit is de constructor van de class. een contructor heeft dezelfde als de class en geen
        // return type
        
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            
            //maakt de muis zichtbaar
            IsMouseVisible = true;

            //geeft de window de naam
            Window.Title = "food Beta 1.0.1";
            

            //veranderd de brete van het spel
            graphics.PreferredBackBufferWidth = 640;
            
            //veranderd de hoogte van het spel
            graphics.PreferredBackBufferHeight = 480;
            
            //past de weizigingen toe
            graphics.ApplyChanges();
        }

       
        protected override void Initialize()
        {

            base.Initialize();
        }

       
        protected override void LoadContent()
        {
            
            spriteBatch = new SpriteBatch(GraphicsDevice);
            this.background = Content.Load<Texture2D>(@"pictures\background");
            this.animatedSprite = Content.Load<Texture2D>(@"pictures\gb_walk");
            this.position = new Vector2(0f,0f);
            this.backgroundRect = new Rectangle((int)this.position.X,
                                               (int)this.position.Y,
                                                this.background.Width,
                                                this.background.Height);
            this.backgroundRect = new Rectangle(0, 0, 640, 480);
            this.enemy = new Enemy(Content, new Vector2(500f, 350f));
            this.walkingMan_1 = new AnimatedSprite(Content, 150, 181, Keys.A, Keys.D, this.enemy, this);
            this.arial = Content.Load<SpriteFont>(@"fonts\Arial");
            this.score = 0;
            this.music = Content.Load<Song>(@"music\day");
            this.day = false;

            this.cameraRect = new Rectangle(0, 0, 640, 480 );
            
        }

        
        protected override void UnloadContent()
        {
            
        }


        protected override void Update(GameTime gameTime)
        {
            this.ks = Keyboard.GetState();

            if (this.ks.IsKeyDown(Keys.Escape))
            {
                this.Exit();
            }
            switch (this.state)
            {
                case GameState.start:
                    if (this.ks.IsKeyDown(Keys.B))
                    {
                        this.state = GameState.play;
                    }
                    break;

                case GameState.play:

                    if (this.score < 0)
                    {
                        this.state = GameState.GameOver;
                    }
                    this.walkingMan_1.update();

                         this.enemy.update();
                    break;

                case GameState.GameOver:

                    if (this.ks.IsKeyDown(Keys.N))
                    {
                        this.state = GameState.start;
                        this.LoadContent();
                    }


                    this.score = 0;
                    
                    break;
            }
                           

            this.oldKeyboardState = this.ks;
            base.Update(gameTime);
        }
               
                
                
                
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.ForestGreen);
            this.spriteBatch.Begin();

            if (this.day == false)
            {
                MediaPlayer.Play(music);
                MediaPlayer.IsRepeating = true;
                this.day = true;
            }
            

            switch (this.state)
            {
                case GameState.start:
                    spriteBatch.Draw(this.background,
                                      this.backgroundRect,
                                      this.cameraRect,
                                      Color.White,
                                      this.timer,
                                      new Vector2(0f, 0f),
                                      SpriteEffects.None,
                                      1f);
                    this.spriteBatch.DrawString(this.arial,
                                       "Druk op B om het spel te starten",
                                       new Vector2(250, 20f),
                                       Color.Black);

                    break;

                case GameState.play:
                     spriteBatch.Draw(this.background,
                                      this.backgroundRect,
                                      this.cameraRect,
                                      Color.White,
                                      this.timer,
                                      new Vector2(0f, 0f),
                                      SpriteEffects.None,
                                      1f);

            //het tekenen van de lopende man.
            this.walkingMan_1.Draw(this.spriteBatch);
            //het tekenen van de vijand.
            this.enemy.Draw(spriteBatch);

            this.spriteBatch.DrawString(this.arial,
                                        "score:" + this.score,
                                        new Vector2(280, 20f),
                                        Color.Black);
                    break;

                case GameState.GameOver:
                       spriteBatch.Draw(this.background,
                                      this.backgroundRect,
                                      this.cameraRect,
                                      Color.White,
                                      this.timer,
                                      new Vector2(0f, 0f),
                                      SpriteEffects.None,
                                      1f);
                    this.spriteBatch.DrawString(this.arial,
                                       "Druk op esc om te stoppen" + "\n druk op n om opnieuw te beginnen",
                                       new Vector2(250, 20f),
                                       Color.Black);
                    break;
            }

                           

            this.spriteBatch.End();

             base.Draw(gameTime);
       }
    }
}
